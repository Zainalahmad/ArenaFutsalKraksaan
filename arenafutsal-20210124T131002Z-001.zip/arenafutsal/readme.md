# Booking Tiket
Aplikasi Booking Tiket Pesawat Online dengan Codeigniter

![alt text](https://image.prntscr.com/image/6Z7_UZ0XSGGEQ3cZKHBMvA.png)
![alt text](https://image.prntscr.com/image/VhQWeFoFTf6WCBmgTkI4sw.png)
![alt text](https://image.prntscr.com/image/uqwuzrUZSMqiOJ41-GyblA.png)
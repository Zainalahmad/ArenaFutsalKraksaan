<header class="main-header">
	<a href="<?php echo base_url(); ?>admin/dashboard" class="logo">
		<span class="logo-mini"><b>A</b>F</span>
		<span class="logo-lg"><img src="<?php echo base_url(); ?>gudang/images/arena.png" width="180px" style="margin: 1px;padding: 0px color:white; alt="Travelo HTML5 Template" /></span>
					
				</a>
	</a>
	<nav class="navbar navbar-static-top">
		<a href="#" class="sidebar-toggle" data-toggle="push-menu" role="button">
			<span class="sr-only">Toggle navigation</span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
			<span class="icon-bar"></span>
		</a>
		<div class="navbar-custom-menu">
			<ul class="nav navbar-nav">
				<li class="dropdown user user-menu">
					<a href="http://localhost/ukk" target="_blank">
						
					</a>
				</li>
			</ul>
		</div>
	</nav>
</header>
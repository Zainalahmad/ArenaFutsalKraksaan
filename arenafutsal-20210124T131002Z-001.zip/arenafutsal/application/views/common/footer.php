<div class="footer-wrapper">
                <div class="container">
                    <div class="row">
                        <div class="col-sm-6 col-md-3">
                            <h2>Laman Kami</h2>
                            <ul class="discover triangle hover row">
                                <li class="active col-xs-6"><a href="#">Home</a></li>
                                <li class="col-xs-6"><a href="#">Lapangan</a></li>
                                <li class="col-xs-6"><a href="#">Cara Booking</a></li>
                                <li class="col-xs-6"><a href="#">Tentang Kami</a></li>
                                <li class="col-xs-6"><a href="#">Hubungi Kami</a></li>
                                <li class="col-xs-6"><a href="#">Social Connect</a></li>
                                
                            </ul>
                        </div>
                        
                        <div class="col-sm-6 col-md-3">
                            <h2>Berlangganan Email</h2>
                            <p>Sign up for our mailing list to get latest updates and offers.</p>
                            <br />
                            <div class="icon-check">
                                <input type="text" class="input-text full-width" placeholder="your email" />
                            </div>
                            <br />
                            <span>We respect your privacy</span>
                        </div>
                        <div class="col-sm-6 col-md-3">
                            <h2>Tentang Kami</h2>
                            <p>Nunc cursus libero purus ac congue arcu cursus ut sed vitae pulvinar massaidp nequetiam lore elerisque.</p>
                            <br />
                            <address class="contact-details">
                                <span class="contact-phone"><i class="soap-icon-phone"></i> 1-800-123-HELLO</span>
                                <br />
                                <a href="#" class="contact-email">arenafutsalkraksaan.com</a>
                            </address>
                            <ul class="social-icons clearfix">
                                <li class="twitter"><a title="twitter" href="#" data-toggle="tooltip"><i class="soap-icon-twitter"></i></a></li>
                                <li class="googleplus"><a title="googleplus" href="#" data-toggle="tooltip"><i class="soap-icon-googleplus"></i></a></li>
                                <li class="facebook"><a title="facebook" href="#" data-toggle="tooltip"><i class="soap-icon-facebook"></i></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="bottom gray-area">
                <div class="container">
                    <div class="pull-left">
                        <a href="index.html" title="Travelo - home">
                            <img src="<?php echo base_url(); ?>gudang/images/arn.png" width="300px" style="margin: 1px;padding: 0px color:white; alt="Travelo HTML5 Template" />
                        </a>
                    </div>
                    <div class="pull-right">
                        <a id="back-to-top" href="#" class="animated" data-animation-type="bounce"><i class="soap-icon-longarrow-up circle"></i></a>
                    </div>
                    <div class="copyright pull-right">
                        <p>&copy; 2020 ArenaFutsal</p>
                    </div>
                </div>
            </div>
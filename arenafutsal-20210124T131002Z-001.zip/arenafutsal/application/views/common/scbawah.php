<!-- Javascript -->
    <script type="text/javascript" src="<?php echo base_url(); ?>gudang/js/jquery-1.11.1.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>gudang/js/jquery.noconflict.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>gudang/js/modernizr.2.7.1.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>gudang/js/jquery-migrate-1.2.1.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>gudang/js/jquery.placeholder.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>gudang/js/jquery-ui.1.10.4.min.js"></script>
    
    <!-- Twitter Bootstrap -->
    <script type="text/javascript" src="<?php echo base_url(); ?>gudang/js/bootstrap.js"></script>
    
    <!-- load revolution slider scripts -->
    <script type="text/javascript" src="<?php echo base_url(); ?>gudang/components/revolution_slider/js/jquery.themepunch.plugins.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>gudang/components/revolution_slider/js/jquery.themepunch.revolution.min.js"></script>

    <!-- Flex Slider -->
    <script type="text/javascript" src="<?php echo base_url(); ?>gudang/components/flexslider/jquery.flexslider-min.js"></script>
    
    <!-- load BXSlider scripts -->
    <script type="text/javascript" src="<?php echo base_url(); ?>gudang/components/jquery.bxslider/jquery.bxslider.min.js"></script>
    
    <!-- parallax -->
    <script type="text/javascript" src="<?php echo base_url(); ?>gudang/js/jquery.stellar.min.js"></script>
    
    <!-- waypoint -->
    <script type="text/javascript" src="<?php echo base_url(); ?>gudang/js/waypoints.min.js"></script>

    <!-- load page Javascript -->
    <script type="text/javascript" src="<?php echo base_url(); ?>gudang/js/theme-scripts.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>gudang/js/scripts.js"></script>
    
    <script type="text/javascript">
        tjq(".flexslider").flexslider({
            animation: "fade",
            controlNav: false,
            animationLoop: true,
            directionNav: false,
            slideshow: true,
            slideshowSpeed: 5000
        });
    </script>
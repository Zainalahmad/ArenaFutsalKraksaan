tjq = jQuery.noConflict();
